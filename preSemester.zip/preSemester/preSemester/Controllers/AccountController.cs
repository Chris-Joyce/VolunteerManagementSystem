﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using preSemester.Models;
using Microsoft.AspNetCore.Http;

namespace preSemester.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            using (MyDbContext db = new MyDbContext())
            {
                return View(db.userAccount.ToList());
            }
        }

        public ActionResult Register()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Register(userAccount account)
        {
            if(ModelState.IsValid)
            {
                using (MyDbContext db = new MyDbContext())
                {
                    db.userAccount.Add(account);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = account.Username + "sucessfully registered";
            }
            return View();
        }

        //login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(userAccount user)
        {
            
            using (MyDbContext db = new MyDbContext())
            {
                var usr = db.userAccount.Where(u => u.Username == user.Username && u.Password == user.Password).FirstOrDefault();
                if (usr != null)
                {
                    
                    Session["UserID"] = usr.UserID.ToString();
                    Session["Username"] = usr.Username.ToString();
                    return RedirectToAction["LoggedIn"];
                  
                }
                else
                {
                    ModelState.AddModelError("", "Username or Password is wrong");
                }
             
            }
            return View();
        }
        public ActionResult LoggedIn()
        {
           if(Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }

}