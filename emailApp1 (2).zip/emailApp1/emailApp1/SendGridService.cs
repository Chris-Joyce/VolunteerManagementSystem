﻿using System.Configuration;
using System.Threading.Tasks;
using SendGrid.emailApp1.Models;
using SendGrid.Helpers.Mail;

namespace SendGrid.emailApp1.Services
{
    public class SendGridService
    {
        private readonly SendGridClient _client;

        public SendGridService()
        {
            // Retrieve the API key from an appSettings variable from the web.config
            var apiKey = ConfigurationManager.AppSettings[""];

            // Initialize the SendGrid client
            _client = new SendGridClient(apiKey);
        }

        public async Task<Response> Send(mail messageInfo)
        {
            // Prepare the SendGrid email message
            var sendgridMessage = new SendGridMessage
            {
                From = new EmailAddress(messageInfo.From),
                Subject = messageInfo.Subject,
                HtmlContent = messageInfo.Body
            };

            // Add the "To" email address to the message
            sendgridMessage.AddTo(new EmailAddress(messageInfo.To));

            // Check if any Cc email address was specified
            if (!string.IsNullOrWhiteSpace(messageInfo.Cc))
            {
                // Add the email address for Cc to the message
                sendgridMessage.AddCc(new EmailAddress(messageInfo.Cc));
            }

            // Send the message to SendGrid, and save the API response
            var response = await _client.SendEmailAsync(sendgridMessage);

            // Return the SendGrid response
            return response;
        }
    }
}