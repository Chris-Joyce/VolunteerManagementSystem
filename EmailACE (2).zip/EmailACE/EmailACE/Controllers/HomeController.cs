﻿using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmailACE.Models;
using System.Net;
using System.Net.Mail;



namespace EmailACE.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "About Page";
            return View();
        }
       

        public ActionResult Contact()
        {
            

            return View();
        }
        [HttpPost]
        public ActionResult Contact(EmailACE.Models.mail model)
        {

            MailMessage message = new MailMessage("huntsville37@gmail.com", model.To);
            message.Subject = model.Subject;
            message.Body = model.Body;
            message.IsBodyHtml = false;

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            //smtp.Host = "smtp.yahoo.com";
            //smtp.Host = "smtp.outlook.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;

            

            smtp.UseDefaultCredentials = true;
            smtp.Credentials = new System.Net.NetworkCredential("huntsville37@gmail.com", "password");
            smtp.Send(message);
            ViewBag.Message = "message sent";
            return View();

        }
    }
}